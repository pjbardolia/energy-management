# Import SQLAlchemy column types
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer

# Import datetime module
from datetime import datetime

# Import Base class from database.py
from database import Base

# Import relationship function from SQLAlchemy
from sqlalchemy.orm import relationship


# Create Data model
class Data(Base):

    # PostgreSQL table name
    __tablename__ = "data"

    # Primary key
    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    # Date and time when data was recorded
    timestamp = Column(
        DateTime,
        default=datetime.utcnow
    )

    # Machine ID imported from machine table
    machine_id = Column(
        Integer,
        ForeignKey("machine.id"),
        nullable=False
    )

    # Component ID imported from machine_component table
    component_id = Column(
        Integer,
        ForeignKey("machine_component.id"),
        nullable=False
    )

    # Output frequency from VFD (Hz)
    output_frequency = Column(
        Float
    )

    # Reference frequency from VFD (Hz)
    reference_frequency = Column(
        Float
    )

    # DC bus voltage (V)
    dc_bus_voltage = Column(
        Float
    )

    # Output voltage (V)
    output_voltage = Column(
        Float
    )

    # Output current (A)
    output_current = Column(
        Float
    )

    # Motor speed (RPM)
    rotation_speed = Column(
        Float
    )

    # Output power (kW)
    output_power = Column(
        Float
    )

    # Output torque
    output_torque = Column(
        Float
    )

    # Temperature value
    temperature = Column(
        Float
    )

    # Pressure value
    pressure = Column(
        Float
    )

    # Relationship to machine table
    machine = relationship(
        "Machine"
    )

    # Relationship to machine_component table
    # Allows:
    # data.component
    component = relationship(
        "MachineComponent",
        back_populates="data_records"
    )
